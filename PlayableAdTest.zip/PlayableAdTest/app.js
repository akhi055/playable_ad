document.addEventListener('DOMContentLoaded', () => {
  const grid = document.querySelector('.grid')
  const scoreDisplay = document.getElementById('score')
  const width = 8
  const squares = []
  let score = 0
  let moves = document.querySelector('#moves')
  const maxMoves = 12;
let movesLeft = maxMoves;
let maxscore = 40
  const candyColors = [
      'images/red_candy.png',
      'images/yellow_candy.png',
      'images/orange_candy.png',
      'images/purple_candy.png',
      'images/green_candy.png',
      'images/blue_candy.png'
  ]
  function createBoard() {
      for (let i = 0; i < width * width; i++) {
          const square = document.createElement('div')
          square.setAttribute('id', i)
          square.setAttribute('draggable', true)
          const img = document.createElement('img')
          let randomColor = Math.floor(Math.random() * candyColors.length)
          img.src = candyColors[randomColor]
          square.appendChild(img)
          grid.appendChild(square)
          squares.push(square)
      }
  }
  createBoard()
  let imgBeingDragged
  let imgBeingReplaced
  let squareIdBeingDragged
  let squareIdBeingReplaced
  squares.forEach(square => square.addEventListener('dragstart', dragStart))
  squares.forEach(square => square.addEventListener('dragend', dragEnd))
  squares.forEach(square => square.addEventListener('dragover', dragOver))
  squares.forEach(square => square.addEventListener('dragenter', dragEnter))
  squares.forEach(square => square.addEventListener('dragleave', dragLeave))
  squares.forEach(square => square.addEventListener('drop', dragDrop))
  function dragStart() {
      imgBeingDragged = this.querySelector('img')
      squareIdBeingDragged = parseInt(this.id)
  }
  function dragOver(e) {
      e.preventDefault()
  }
  function dragEnter(e) {
      e.preventDefault()
  }
  function dragLeave() {}
  function dragDrop() {
      imgBeingReplaced = this.querySelector('img')
      squareIdBeingReplaced = parseInt(this.id)
      this.appendChild(imgBeingDragged)
      squares[squareIdBeingDragged].appendChild(imgBeingReplaced)
      moves--;
      updateMovesLeft();   
  }
  function dragEnd() {
      let validMoves = [squareIdBeingDragged - 1, squareIdBeingDragged - width, squareIdBeingDragged + 1, squareIdBeingDragged + width]
      let validMove = validMoves.includes(squareIdBeingReplaced)
      if (squareIdBeingReplaced && validMove) {
          squareIdBeingReplaced = null
          movesLeft--
          updateMovesLeft()
      } else if (squareIdBeingReplaced && !validMove) {
          squares[squareIdBeingReplaced].appendChild(imgBeingReplaced)
          squares[squareIdBeingDragged].appendChild(imgBeingDragged)
      } else {
          squares[squareIdBeingDragged].appendChild(imgBeingDragged)
      }
      setTimeout(() => {
          checkMatches()
      }, 100)
  }
  function moveIntoSquareBelow() {
      for (let i = 0; i < 55; i++) {
          if (!squares[i + width].querySelector('img')) {
              squares[i + width].appendChild(squares[i].querySelector('img'))
              if (!squares[i].querySelector('img')) {
                  const img = document.createElement('img')
                  let randomColor = Math.floor(Math.random() * candyColors.length)
                  img.src = candyColors[randomColor]
                  squares[i].appendChild(img)
              }
          }
      }
  }
  function checkMatches() {
      checkRowForFour()
      checkColumnForFour()
      checkRowForThree()
      checkColumnForThree()
      setTimeout(moveIntoSquareBelow, 100)
  }
function checkRowForFour() {
  for (let i = 0; i < 60; i++) {
      let rowOfFour = [i, i + 1, i + 2, i + 3]
      let decidedColor = squares[i].querySelector('img') ? squares[i].querySelector('img').src : ''
      const isBlank = !squares[i].querySelector('img')
      const notValid = [5, 6, 7, 13, 14, 15, 21, 22, 23, 29, 30, 31, 37, 38, 39, 45, 46, 47, 53, 54, 55]
      if (notValid.includes(i)) continue
      if (rowOfFour.every(index => squares[index].querySelector('img') && squares[index].querySelector('img').src === decidedColor && !isBlank)) {
          score += 4
          scoreDisplay.innerHTML = `${score}/${maxscore}`
          rowOfFour.forEach(index => {
              squares[index].querySelector('img').remove()
              const img = document.createElement('img')
              let randomColor = Math.floor(Math.random() * candyColors.length)
              img.src = candyColors[randomColor]
              squares[index].appendChild(img)
          })
      }
  }
}
function checkColumnForFour() {
  for (let i = 0; i < 39; i++) {
      let columnOfFour = [i, i + width, i + width * 2, i + width * 3]
      let decidedColor = squares[i].querySelector('img') ? squares[i].querySelector('img').src : ''
      const isBlank = !squares[i].querySelector('img')

      if (columnOfFour.every(index => squares[index].querySelector('img') && squares[index].querySelector('img').src === decidedColor && !isBlank)) {
          score += 4
          scoreDisplay.innerHTML = `${score}/${maxscore}`
          columnOfFour.forEach(index => {
              squares[index].querySelector('img').remove()
              const img = document.createElement('img')
              let randomColor = Math.floor(Math.random() * candyColors.length)
              img.src = candyColors[randomColor]
              squares[index].appendChild(img)
          })
      }
  }
}
function checkRowForThree() {
  for (let i = 0; i < 61; i++) {
      let rowOfThree = [i, i + 1, i + 2]
      let decidedColor = squares[i].querySelector('img') ? squares[i].querySelector('img').src : ''
      const isBlank = !squares[i].querySelector('img')
      const notValid = [6, 7, 14, 15, 22, 23, 30, 31, 38, 39, 46, 47, 54, 55]
      if (notValid.includes(i)) continue
      if (rowOfThree.every(index => squares[index].querySelector('img') && squares[index].querySelector('img').src === decidedColor && !isBlank)) {
          score += 3
          scoreDisplay.innerHTML = `${score}/${maxscore}`
          rowOfThree.forEach(index => {
              squares[index].querySelector('img').remove()
              const img = document.createElement('img')
              let randomColor = Math.floor(Math.random() * candyColors.length)
              img.src = candyColors[randomColor]
              squares[index].appendChild(img)
          })
      }
  }
}
function checkColumnForThree() {
  for (let i = 0; i < 47; i++) {
      let columnOfThree = [i, i + width, i + width * 2]
      let decidedColor = squares[i].querySelector('img') ? squares[i].querySelector('img').src : ''
      const isBlank = !squares[i].querySelector('img')

      if (columnOfThree.every(index => squares[index].querySelector('img') && squares[index].querySelector('img').src === decidedColor && !isBlank)) {
          score += 3
          scoreDisplay.innerHTML = `${score}/${maxscore}`
          columnOfThree.forEach(index => {
              squares[index].querySelector('img').remove()
              const img = document.createElement('img')
              let randomColor = Math.floor(Math.random() * candyColors.length)
              img.src = candyColors[randomColor]
              squares[index].appendChild(img)
          })
      }
  }
}
let lastScore = 0 
const intervalId = window.setInterval(function () {
    checkMatches()
    if (score > lastScore) {
        lastScore = score;
        if (movesLeft === 0 && score < maxscore) {
            clearInterval(intervalId);
            endGame("You lose! Score: " + score)
        } else if (score >= maxscore) {
            clearInterval(intervalId);
            endGame("You won! Score: " + score)  
          }
    }
    updateMovesLeft()
}, 100)

function updateMovesLeft() {
    if (movesLeft === 0 && score < maxscore) {
      clearInterval(intervalId);
      endGame("You lose! Score: " + score)
  }
    moves.innerHTML = movesLeft;
}
updateMovesLeft()
function endGame(message) {
  alert(message)
  squares.forEach(square => {
      square.removeAttribute('draggable');
      square.removeEventListener('dragstart', dragStart);
      square.removeEventListener('dragover', dragOver);
      square.removeEventListener('dragenter', dragEnter);
      square.removeEventListener('dragleave', dragLeave);
      square.removeEventListener('drop', dragDrop);
  });
}
 
})
