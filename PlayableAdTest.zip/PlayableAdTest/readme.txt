Prepare the Project Files:
You'll need three files for this playable ad:
1.index.html → Main structure (HTML)
2.style.css → Styling (CSS)
3.app.js & candies.js → Game logic (JavaScript)

Option 1: Open in a Browser (Fastest)
1️⃣ Double-click index.html to open in Chrome/Firefox.
2️⃣ The game grid will load.
3️⃣ The "Install" button will appear in the bottom-right corner.
4️⃣ Clicking the Install button redirects to Candy Crush Saga on the Play Store.

Option 2: Run with Live Server (Recommended)
If you’re using VS Code, follow these steps:
1️⃣ Install the Live Server extension.
2️⃣ Right-click on index.html → Open with Live Server.
3️⃣ Your game will open in a browser tab.